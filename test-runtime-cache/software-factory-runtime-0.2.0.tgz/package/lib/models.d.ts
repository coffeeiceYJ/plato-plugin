import type { Context } from '@deepseek-ai/cordis';
import type { ModelRef, ModelRequest, ModelResponse } from './contracts/runtime.js';
/** One isolated, tool-free DSH Session per model call. No Agent is created. */
export declare function callModel(ctx: Context, selection: ModelRef | undefined, request: ModelRequest, directory: string, workspace: string, signal: AbortSignal): Promise<ModelResponse>;
