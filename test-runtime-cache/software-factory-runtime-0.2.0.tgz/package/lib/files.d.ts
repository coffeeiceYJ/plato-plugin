import type { RunRecord, RunEvent, RunRequest } from './contracts/runtime.js';
export declare function safeDirectory(root: string, path: string): Promise<string>;
export declare function taskFile(root: string, path: string): Promise<string>;
/** Read an existing directory under a workspace; never create it or follow links. */
export declare function taskDirectory(root: string, path: string): Promise<string>;
export declare function saveJson(path: string, data: unknown): Promise<void>;
export interface StoredRun {
    record: RunRecord;
    events: RunEvent[];
    directory: string;
}
export declare function createRunDirectory(workspace: string, runId: string, input: RunRequest): Promise<string>;
export declare function loadHistory(workspace: string): Promise<StoredRun[]>;
