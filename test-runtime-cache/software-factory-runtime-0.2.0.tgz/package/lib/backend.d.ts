import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { ToolDefinition, ToolRunContext, ToolExecutionToken } from '@deepseek-ai/dsh-tools';
import type { ExecutionContext } from './sdk/index.js';
import type { RunRecord, RunSummary, RunEvent, RunRequest, ToolContract, ListRunsRequest, Artifact, WaitRunRequest, RunUpdate } from './contracts/runtime.js';
export interface RuntimeConfig {
    defaultTimeoutMs?: number;
    modelTimeoutMs?: number;
}
/** Private implementation; only the facade and validated SDK execution can reach it. */
export declare class RunBackend {
    private ctx;
    private config;
    private entries;
    private runs;
    private loaded;
    private jobs;
    private active;
    constructor(ctx: Context, config: RuntimeConfig);
    registerEntry(tool: ToolDefinition): () => void;
    private caller;
    private entry;
    contract(agent: Agent, toolId: string): Promise<ToolContract>;
    start(agent: Agent, input: RunRequest, parent?: ToolExecutionToken): Promise<{
        runId: string;
        status: 'queued';
    }>;
    private inheritModel;
    private verifyModel;
    private perform;
    private cleanup;
    private stop;
    executionFor(exec: ToolRunContext, tool: ToolDefinition): ExecutionContext;
    private track;
    private addArtifact;
    private emit;
    private find;
    private artifactView;
    private recordView;
    get(agent: Agent, runId: string): Promise<RunRecord>;
    list(agent: Agent, input: ListRunsRequest): Promise<{
        items: RunSummary[];
        total: number;
    }>;
    private summary;
    cancel(agent: Agent, runId: string): Promise<{
        runId: string;
        status: import("./sdk/index.js").RunStatus;
    }>;
    wait(agent: Agent, input: WaitRunRequest, signal?: AbortSignal): Promise<RunUpdate>;
    watch(agent: Agent, runId: string, afterSeq?: number, signal?: AbortSignal): AsyncGenerator<RunEvent>;
    getArtifact(agent: Agent, runId: string, artifactId: string): Promise<Artifact>;
    download(agent: Agent, runId: string, artifactId: string): Promise<{
        file: Artifact;
        bytes: NonSharedBuffer;
    }>;
    dispose(): Promise<void>;
}
